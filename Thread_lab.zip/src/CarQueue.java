import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
/*
 * Montana Bazarragchaa
 * 
 * CMSC 204
 */


/**
 * Constructor initializes the queue with 6 random directions.
 * 0 = up, 1 = down, 2 = right, 3 = left
 */
public class CarQueue {

	Queue<Integer> carQueue;	
	Random addRandomValues;
	public CarQueue() {
		
		
		carQueue = new LinkedList<Integer>();
		
		addRandomValues = new Random();
		
		carQueue.add(addRandomValues.nextInt(4));
		carQueue.add(addRandomValues.nextInt(4));
		carQueue.add(addRandomValues.nextInt(4));
		carQueue.add(addRandomValues.nextInt(4));
		carQueue.add(addRandomValues.nextInt(4));
		carQueue.add(addRandomValues.nextInt(4));
		
	}
	
	
    /**
     * Adds a random direction to the queue every 10ms in a new thread.
     */
	public void addToQueue() {
					
		class addToQueRunnableInnerClass implements Runnable {
	
					@Override
					public void run() {
							try {								
								while (true) {
									
									carQueue.add(addRandomValues.nextInt(4));
									Thread.sleep(10);
								}
								
							} catch (InterruptedException e) {
								e.printStackTrace();
							}
						
					}
				
				
			}
		
			addToQueRunnableInnerClass myAddToQueRunnableInnerClass = new addToQueRunnableInnerClass();

			Thread threadForAddToQueRunnableInnerClass = new Thread(myAddToQueRunnableInnerClass);

			threadForAddToQueRunnableInnerClass.start();
	}
	

    /**
     * Removes and returns the next direction from the queue.
     * 
     * @return The direction value (0, 1, 2, or 3)
     */
	public int deleteQueue() {
		
	int	deleteQueueValue = carQueue.remove();
		
		return deleteQueueValue;
	}
}
