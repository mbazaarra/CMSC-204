/** CMSC 204 
 *  Montana Bazarragchaa
 */


import java.util.ArrayList;


public class PasswordCheckerUtility {

    public PasswordCheckerUtility() {
    }

    /**
     * Checks if the password is valid based on all rules.
     * Throws exceptions for any invalid rule.
     */
    public static boolean isValidPassword(String password)
            throws LengthException, NoUpperAlphaException, NoLowerAlphaException, NoDigitException, NoSpecialCharacterException, InvalidSequenceException {

        length(password);
        upperAlpha(password);
        lowerAlpha(password);
        digit(password);
        specialChar(password);
        invalidSeq(password);

        return true; // Password is valid if no exceptions
    }

    /**
     * Compares two passwords and throws an exception if they don't match.
     */
    public static void comparePasswords(String password, String passwordConfirm) throws UnmatchedException {
        if (!password.equals(passwordConfirm)) {
            throw new UnmatchedException();
        }
    }

    /**
     * Compares two passwords and returns true if they match.
     */
    public static boolean comparePasswordsWithReturn(String password, String passwordConfirm) {
        return password.equals(passwordConfirm);
    }

    /**
     * Checks if the password has at least one uppercase letter.
     */
    public static boolean hasUpperAlpha(String password) throws NoUpperAlphaException {
        for (int i = 0; i < password.length(); i++) {
            if (Character.isUpperCase(password.charAt(i))) {
                return true;
            }
        }
        throw new NoUpperAlphaException();
    }

    /**
     * Checks if the password is at least 6 characters long.
     */
    public static boolean isValidLength(String password) throws LengthException {
        if (password.length() >= 6) {
            return true;
        } else {
            throw new LengthException();
        }
    }

    /**
     * Checks if the password is weak (6-9 characters long).
     */
    public static boolean isWeakPassword(String password) throws LengthException, WeakPasswordException {
        if (password.length() >= 6 && password.length() <= 9) {
            throw new WeakPasswordException();
        }
        return false;
    }

    /**
     * Returns a list of invalid passwords with error messages.
     */
    public static ArrayList<String> getInvalidPasswords(ArrayList<String> passwords) {
        ArrayList<String> invalidPasswords = new ArrayList<>();

        for (String password : passwords) {
            try {
                isValidPassword(password);
            } catch (Exception e) {
                invalidPasswords.add(password + " " + e.getMessage());
            }
        }
        return invalidPasswords;
    }

    // Helper methods for specific password checks

    /**
     * Checks if the password is too short.
     */
    private static void length(String password) throws LengthException {
        if (password.length() < 6) {
            throw new LengthException();
        }
    }

    /**
     * Checks if the password has an uppercase letter.
     */
    private static void upperAlpha(String password) throws NoUpperAlphaException {
        if (!password.matches(".*[A-Z].*")) {
            throw new NoUpperAlphaException();
        }
    }

    /**
     * Checks if the password has a lowercase letter.
     */
    private static void lowerAlpha(String password) throws NoLowerAlphaException {
        if (!password.matches(".*[a-z].*")) {
            throw new NoLowerAlphaException();
        }
    }

    /**
     * Checks if the password has a digit.
     */
    private static void digit(String password) throws NoDigitException {
        if (!password.matches(".*\\d.*")) {
            throw new NoDigitException();
        }
    }

    /**
     * Checks if the password has a special character.
     */
    private static void specialChar(String password) throws NoSpecialCharacterException {
        if (password.matches("[a-zA-Z0-9]*")) {
            throw new NoSpecialCharacterException();
        }
    }

    /**
     * Checks if the password has more than two identical characters in a row.
     */
    private static void invalidSeq(String password) throws InvalidSequenceException {
        for (int i = 0; i < password.length() - 2; i++) {
            if (password.charAt(i) == password.charAt(i + 1) && password.charAt(i) == password.charAt(i + 2)) {
                throw new InvalidSequenceException();
            }
        }
    }
    
}

