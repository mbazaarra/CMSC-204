
public class UnmatchedException extends Exception{

	//Exception class to throw UnmatchedException from the GUI
	public UnmatchedException() {
		super("Passwords do not match");
	}
}
